
/**
 * Write a description of class TurtleDrawer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TurtleDrawer
{
    private Turtle pen;
    
    public TurtleDrawer() {
        pen = new Turtle();
        pen.setPenColor("black");
        pen.penDown();
    }
    
    
}
