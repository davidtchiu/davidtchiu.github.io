import java.util.ArrayList;

/**
 * Add your comments here
 * 
 * @author (name)
 * @version (date)
 */
public class SuperCircleDrawer
{
    // define your field(s) here
    
    /**
     * Constructor
     */
    public SuperCircleDrawer(int numCircles)
    {
        // your code here
    }
        
}
