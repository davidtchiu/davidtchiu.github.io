import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * (Write a description of class Image here.)
 *
 * @author (Your name)
 * @version (a version number or a date)
 */
public class Image
{
    private int height;
    private int width;
    private int[][] canvas;

    /**
     * No changes to this constructor needed.
     */
    public Image(String filename) {
        open(filename);
    }

    /**
     * This transformation inverts all Pixels to their negative
     * values in the current Image.
     */
    public void inverse() {
        // TODO
    }

    /**
     * This transformation adjusts the intensity of all Pixels in the current Image
     * using the Power Law (gamma).
     * 
     * @param   gamma   exponent
     */
    public void gamma(double gamma) {
        // TODO
    }

    /**
     * Reduces "noise" in the image. Also known as smoothing.
     * It computes the current pixel value as the average of its neighbors.
     */
    public void smooth() {
        // TODO
    }

    /**
     * Flip the image horizontally
     * 
     */
    public void flipHorizontal() {
        // TODO
    }

    /**
     * Flip the image vertically
     */
    public void flipVertical() {
        // TODO
    }

    /*********************************************
     * 
     * DO NOT EDIT ANYTHING BELOW THIS COMMENT
     * 
     * BUT READ THE METHODS' COMMENTS AND SIGNATURE
     * TO UNDERSTAND HOW TO USE THEM IN YOUR CODE
     * 
     ********************************************/

    /**
     * The String representation of this image.
     */
    public String toString() {
        StringBuffer strBuffer = new StringBuffer();
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                strBuffer.append(canvas[i][j] + " ");
            }
            strBuffer.append("\n");
        }
        return strBuffer.toString();       
    }

    /**
     * Open an image file.
     * 
     * @param   filename is a path to the inage file to be opened
     */
    public void open(String filename) {        
        File f = new File(filename);
        try {
            BufferedImage image = ImageIO.read(new File(filename));

            // Set dimensions
            this.width = image.getWidth();
            this.height = image.getHeight();
            this.canvas = new int[this.height][this.width];

            // Convert each pixel to grayscale
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {

                    int rgb = image.getRGB(x, y);

                    // Extract color components
                    int red = (rgb >> 16) & 0xFF;
                    int green = (rgb >> 8) & 0xFF;
                    int blue = rgb & 0xFF;

                    // Calculate grayscale intensity (luminance formula)
                    int gray = (int) (0.3 * red + 0.59 * green + 0.11 * blue);

                    // Set the grayscale intensity
                    int grayPixel = (gray << 16) | (gray << 8) | gray;
                    this.canvas[y][x] = grayPixel & 0xFF;
                }
            }
        }
        catch(IOException e) {
            System.err.println("Error opening " + filename + ": " + e.toString());
            System.exit(-1);
        }
    }

    /**
     * Writes contents of current Image into the file that is specified.
     * 
     * @param   targetFilename    The name of file into which to save current image.
     */
    public void save(String targetFilename) {
        File f = new File(targetFilename);
        try {
            BufferedImage grayscaleImage = new BufferedImage(this.width, this.height, BufferedImage.TYPE_BYTE_GRAY);
            // Convert each pixel to grayscale
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    grayscaleImage.getRaster().setSample(x, y, 0, this.canvas[y][x]);
                }
            }            
            ImageIO.write(grayscaleImage, "jpg", new File(targetFilename));
            System.err.println("Success!");
        }
        catch(IOException e) {
            System.err.println("Error saving " + targetFilename + ": " + e.toString());
            System.exit(-1);
        }
    }
}
