
/**
 * Write a description of class Photoshop here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fotoshop {   
    public static void main(String[] args) {
        Image pic = new Image("camera.jpg");
        pic.inverse();
        pic.save("camera-inverse.jpg");

        /*
         * You can also do multiple transformations at once.
         * Image pic = new Image("cat.jpg");
         * pic.flipVertical();
         * pic.inverse();
         * pic.smooth();
         * pic.smooth();
         * pic.save("smoothcat.jpg");
         */
        
    }
}


