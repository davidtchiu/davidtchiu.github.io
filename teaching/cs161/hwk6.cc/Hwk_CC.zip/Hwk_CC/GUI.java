import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * This class provides a GUI interface for checking the validity of standardized
 * sequences.
 * 
 * @author David
 */
public class GUI implements ActionListener {
  private CCValidator validator; // The checker to use for sequence verification
  private JPanel displayPanel; // The panel that holds the display
  private JPanel resultPanel; // The panel that holds the display
  private JTextArea inputText; // The text display
  private JTextArea resultDisplay; // The Result display
  private JFrame frame; // The frame that holds the display and key panels
  private JButton buttonVerify;
  private JButton buttonClear;
  private JButton buttonExit;

  public GUI(CCValidator checker) {
    this.validator = checker;

    // Build the frame holding the Controller components
    this.frame = new JFrame("Validation");
    this.frame.setSize(300, 350);
    this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Display is in a separate panel -- the NORTH panel of border layout
    this.inputText = new JTextArea(1, 30);
    this.inputText.setEditable(true);
    this.inputText.setLineWrap(true);
    this.inputText.setWrapStyleWord(true);
    this.inputText.setFont(new Font("Menlo", Font.PLAIN, 15));
    this.displayPanel = new JPanel();
    this.displayPanel.add(new JLabel("Enter sequence: "));
    this.displayPanel.add(this.inputText);

    this.resultDisplay = new JTextArea(2, 30);
    this.resultDisplay.setBackground(Color.BLACK);
    this.resultDisplay.setEditable(false);
    this.resultDisplay.setFont(new Font("Menlo", Font.PLAIN, 15));
    this.resultPanel = new JPanel();
    this.resultPanel.add(this.resultDisplay);

    // Create the buttons and register this object as listener for each
    this.buttonClear = new JButton("Clear");
    this.buttonClear.addActionListener(this);
    this.buttonVerify = new JButton("Verify");
    this.buttonVerify.addActionListener(this);
    this.buttonExit = new JButton("Quit");
    this.buttonExit.addActionListener(this);

    // There's a panel in the CENTER of the layout holding the direction keys
    JPanel keys = new JPanel();
    keys.add(this.buttonClear);
    keys.add(this.buttonVerify);
    keys.add(this.buttonExit);

    JPanel displays = new JPanel(new GridLayout(3, 1));
    displays.add(this.displayPanel);
    displays.add(this.resultPanel);
    displays.add(keys);
    this.frame.add(displays);
    this.frame.pack();
    this.frame.setVisible(true);
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == this.buttonExit) {
      System.exit(0);
    } else if (e.getSource() == this.buttonClear) {
      this.inputText.setText("");
      this.resultDisplay.setText("");
      this.resultDisplay.setBackground(Color.BLACK);
    } else {
      // attempt to load sequence
      if (!this.validator.loadSequence(this.inputText.getText())) {
        // did not validate due to length
        this.resultDisplay.setForeground(Color.WHITE);
        this.resultDisplay.setBackground(Color.RED);
        this.resultDisplay.setText("Card declined! Input length should be 16.");
      } else {
        if (this.validator.validate()) {
          this.resultDisplay.setForeground(Color.BLACK);
          this.resultDisplay.setBackground(Color.GREEN);
          this.resultDisplay.setText("Card is valid!");
        } else {
          this.resultDisplay.setForeground(Color.WHITE);
          this.resultDisplay.setBackground(Color.RED);
          this.resultDisplay.setText("Card declined! Double-check the number.");
        }
      }

    }
    this.inputText.grabFocus();
  }
}