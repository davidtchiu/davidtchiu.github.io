import java.util.*;

/**
 * Election class for Lab.
 *
 * @author David
 * @version 4/15/2020
 */
public class BallotCounter {
   
    /**
     * Starts a new election.
     */
    public BallotCounter() {
        // TODO
    }
    
    /**
     * Repeatedly obtains votes from the terminal, until "quit" is
     * entered.
     */
    public void inputVotes() {
        // TODO: create a Scanner object, and associate it with keyboard
        // TODO: loop as long as "quit" is not entered
        // TODO: If a candidate doesn't exist in the hashmap, add them and give them one vote
        // TODO: If they already exist in the hashmap, simply increment their vote
    }    

    /**
     * @return the total number of votes cast in this election
     */
    public int totalVotes() {
        // TODO
        return 0;
    }
    
    /**
     * @return difference of votes between two candidates
     */
    public double margin(String candidate1, String candidate2) {
        // TODO: obtain the difference of votes between the two candidates
        // as a percentage. If a given candidate doesn't exist, your method should
        // return "not a number" (Double.NaN)
        return Double.NaN;
    }

    /**
     * Determines the winners (could mean multiple)
     * @return a list of winners from the election 
     * @pre Precondition: inputVotes() must be run before this method is called
     */
    public ArrayList<String> winners() {
        // create an ArrayList to return
        ArrayList<String> winners = new ArrayList<>();

        // TODO: Find all the candidates who have the highest (use King-of-the-Hill)
        // vote count, add them to the winners list!
        
        return winners;
    }

    /**
     * Prints election results
     * @pre Precondition: inputVotes() must be run before this method is called
     */
    public void printResults() {
        // TODO
    }

}