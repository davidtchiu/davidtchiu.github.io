/**
 * This code represents a class of diamonds, which are
 * composed of two triangles.
 *
 * @author <Your name>
 * @version <Date>
 */
public class Diamond {
    // instance variables
    private ...
    
    
    /**
     * Creates a new diamond and draws it on canvas
     */
    public Diamond() {
        // TODO: instantiate top and bottom triangles
        // TODO: get them in the right positions
    }
        
    /**
     * Draws the diamond on the canvas
     */
    public void makeVisible() {
        // TODO
    }

    /**
     * Hides the diamond from the canvas
     */
    public void makeInvisible() {
        // TODO
    }

    /* TODO: fill in the rest of the methods */
}
