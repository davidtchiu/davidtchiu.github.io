import java.util.*;

/**
 * This class represents a single hand for the game, Black Jack.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hand
{
    // instance variables
    private ArrayList<Card> hand;
    
    /**
     * The constructor is used for testing. It allows us to input
     * any number of Cards as the hand.
     * @param testHand This is a variable-length argument! You can add 
     *                  as many Card objects as you like, separated by
     *                  commas.
     * For example:
     * Hand h = new Hand(new Card(Suit.CLUB, 1), new Card(Suit.HEART, 13));
     * System.out.println(h.isBlackJack());
     */
    public Hand(Card... testHand) {
        // Meant for testing
        hand = new ArrayList<Card>(Arrays.asList(testHand));
    }
    
}
