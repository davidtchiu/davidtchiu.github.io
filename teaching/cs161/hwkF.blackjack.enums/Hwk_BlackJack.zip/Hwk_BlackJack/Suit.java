
/**
 * This enumeration class defines constants for a card's suit.
 * 
 * DO NOT MAKE CHANGES TO THIS CLASS!!!
 *
 * @author David
 * @version 4/19/2020
 */
public enum Suit {
    DIAMOND, HEART, SPADE, CLUB
}
