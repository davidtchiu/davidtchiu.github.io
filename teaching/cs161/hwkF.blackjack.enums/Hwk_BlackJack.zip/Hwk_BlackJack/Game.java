
/**
 * This is the main black jack method
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Game {

    /**
     * The main method! This is where your app gets
     * started!
     */
    public static void main(String[] args) {
        // Get your game started!
        // Create a Deck, replenish to 52 cards, shuffle it
        // Create two Hands: one for yourself, and one for AI dealer
        // ...
    }
}
