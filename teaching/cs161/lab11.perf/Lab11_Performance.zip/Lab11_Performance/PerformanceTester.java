import java.util.Random;

/**
 * A class that runs performance experiments.
 * 
 * @author David Chiu and America Chambers
 * @version 10/17/2016
 */
public class PerformanceTester {   
    private static Random rng = new Random();
    
    /**
     * Runs a linear search experiment with the given configurations.
     * 
     * @param N The list size
     * @param numRuns The number of runs per new problem size
     * @param unordered   Specifies whether an unordered (or ordered) list should be used
     */
    public static void testLinearSearch(int N, int numRuns, boolean unordered) {
        //max, min, and average number of comparisons
        long maxComps = Long.MIN_VALUE;
        long minComps = Long.MAX_VALUE;
        long totalComps = 0;

        //create a ListSearcher and generate unordered data
        ListSearcher s = new ListSearcher(N);
        if (unordered) {
            s.generateUnorderedData();
        }
        else {
            s.generateOrderedData();
        }

        //inner loop to run trials
        for (int trial = 0; trial < numRuns; trial++) {
            s.resetComparisons();               //reset comparison count
            int key = rng.nextInt(N);           //generate a random key from 0 to N-1
            s.linearSearch(key);                //call linearSearch
            long numComps = s.getComparisons();  //retrieve number of comparisons

            //update max, min, total
            if (numComps > maxComps) {
                maxComps = numComps;
            }
            if (numComps < minComps) {
                minComps = numComps;
            }
            totalComps += numComps;
        }
        System.out.println("N=" + N + ", " 
            + "best=" + minComps + " (expected 1), " 
            + "worst=" + maxComps + " (expected " + N + "), "
            + "avg=" + (long) ((double)totalComps/numRuns) 
            + " (expected " + (long) Math.ceil(N/2.0) + ")");
    }

    /**
     * Runs a binary search experiment with the given configurations.
     * 
     * @param N The list size
     * @param numRuns The number of runs per new problem size
     */
    public static void testBinarySearch(int N, int numRuns) {
        Random rng = new Random();

        //max, min, and average number of comparisons
        long maxComps = Long.MIN_VALUE;
        long minComps = Long.MAX_VALUE;
        long totalComps = 0;

        //create a ListSearcher and generate unordered data
        ListSearcher s = new ListSearcher(N);
        s.generateOrderedData();

        //inner loop to run trials
        for (int trial = 0; trial < numRuns; trial++) {
            s.resetComparisons();               //reset comparison count
            int key = rng.nextInt(N);           //generate a random key from 0 to N-1
            s.binarySearch(key);                //call binarySearch
            long numComps = s.getComparisons();  //retrieve number of comparisons

            //update max, min, total
            if (numComps > maxComps) {
                maxComps = numComps;
            }
            if (numComps < minComps) {
                minComps = numComps;
            }
            totalComps += numComps;
        }
        System.out.println("N=" + N + ", " 
            + "best=" + minComps + " (expected 1), " 
            + "worst=" + maxComps + " (expected " + (int) Math.ceil(Math.log(N)/Math.log(2.0)) + "), "
            + "avg=" + (long) ((double)totalComps/numRuns));
    }

    /**
     * Runs a median finding experiment with the given configurations
     * @param N The list size
     * @param numRuns the number of runs per new problem size
     * @param unordered   Specifies whether an unordered (or ordered) list should be used
     */
    public static void testMedian(int N, int numRuns, boolean unordered){

        // max, min, and average number of comparisons
        long maxComps = Long.MIN_VALUE;
        long minComps = Long.MAX_VALUE;
        long totalComps = 0;

        // create a ListSearcher
        ListSearcher s = new ListSearcher(N);
        for (int trial = 0; trial < numRuns; trial++) {

            //generate data (so that the median changes)
            if (unordered) {
                s.generateUnorderedData();
            }
            else {
                s.generateOrderedData();
            }

            // Count number of comparisons to find the median
            s.resetComparisons();
            s.findMedian();
            long numComps = s.getComparisons();

            if(numComps > maxComps) {
                maxComps = numComps;
            }
            if(numComps < minComps) {
                minComps = numComps;
            }
            totalComps += numComps;
        }
        System.out.println("N=" + N + ", " 
            + "best=" + minComps + ", " 
            + "worst=" + maxComps + ", "
            + "avg=" + (long) ((double)totalComps/numRuns));
    }
}