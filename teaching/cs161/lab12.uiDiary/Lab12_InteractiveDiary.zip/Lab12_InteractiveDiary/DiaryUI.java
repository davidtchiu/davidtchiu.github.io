import java.util.Scanner;
import java.util.ArrayList;
/**
 * This is a user interface (UI) for the diary!
 * We will repeatedly present a menu of option to users.
 *
 * @author (Your name)
 * @version (Today's date)
 */
public class DiaryUI {
    private Diary myDiary;
    
    public DiaryUI() {
        myDiary = new Diary();
    }
    
    /**
     * Starts this User Interface!
     */
    public void start() {
        System.out.println("You are using the Diary App!");

        // TODO - All of your work goes below here
    }
    
    /**
     * Displays a command menu to users
     */
    private void printMenu() {
        System.out.println("The Diary App supports the following commands.");
        System.out.println(" 'new': write a new entry");
        System.out.println(" 'edit': modify an existing entry");
        System.out.println(" 'search': perform a keyword search");
        System.out.println(" 'print': prints out all entries of your diary");
        System.out.println(" 'quit'");
        System.out.print("Your command: ");
    }
}
