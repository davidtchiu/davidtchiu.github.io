import java.util.ArrayList;

/**
 * This class represents a simple diary. Our diary
 * is stored using an expandable (and shrinkable) 
 * ArrayList of Strings.
 *
 * @author David
 * @version 4/7/2024
 */
public class Diary {
    private ArrayList<String> entryList;

    public Diary() {
        // Instantiate the ArrayList of Strings
        entryList = new ArrayList<String>();
    }

    /**
     * Adds a new entry to the diary
     */
    public void writeEntry(String entry) {
        // Appends a new entry to the ArrayList!
        entryList.add(entry);
    }

    /**
     * Deletes and returns the final entry
     * @returns the last entry, or null if the list was empty
     */
    public String undo() {
        if (entryList.size() == 0) {
            // diary was empty: do not attempt to remove 
            // and simply return null.
            return null;
        }
        
        // delete and return the final entry
        return entryList.remove(entryList.size()-1);
    }
    
    /**
     * Modifies an existing entry.
     * @return the entry at the specified index, or null if index is invalid
     */
    public String edit(int index, String newEntry) {
        if (index >= 0 && index < entryList.size()) {
            String old = entryList.get(index);  // save old entry
            entryList.set(index, newEntry);     // replace entry
            return old;
        }
        return null;
    }
    
    /**
     * Removes the longest entry. No effect if list is empty.
     */
    public void removeLongestEntry() {
        if (entryList.size() > 0) {
            int longest = 0;    // position of the longest entry
            for (int i = 1; i < entryList.size(); i++) {
                if (entryList.get(longest).length() < entryList.get(i).length()) {
                    // found a longer entry at 'i'; Save 'i'
                    longest = i;
                }
            }
            
            // remove longest entry
            entryList.remove(longest);
        }
    }
    
    /**
     * @return the entry at the specified index, or null if index is invalid
     */
    public String getEntry(int index) {
        if (index >= 0 && index < entryList.size()) {
            return entryList.get(index);
        }
        return null;
    }

    /**
     * Prints all diary entries
     */
    public void printAll() {
        for (int i = 0; i < entryList.size(); i++) {
            System.out.println(("#" + i + ": " + entryList.get(i)));
        }
    }

    /**
     * @return a list of entries containing the search string
     */
    public ArrayList<String> search(String target) {
        // a temporary list to hold the search results
        ArrayList<String> results = new ArrayList<>();
        
        // use a for-each loop to iterate through all entries
        // (We don't care about indices in this loop)
        for (String entry : entryList) {
            // found an entry with the search string
            if (entry.contains(target)) {
                // add it to the list of results!
                results.add(entry);
            }
        }
        return results;
    }

    /**
     * @return the number of entries containing the search string
     */
    public int countEntriesContaining(String target) {
        // Our search() method returns an ArrayList of results.
        // So just ask for its size.
        return search(target).size();
    }

    /**
     * Deletes all entires containing the search string
     */
    public void removeEntriesContaining(String target) {
        // iterate through all entries looking for the search string
        for (int i = 0; i < entryList.size(); i++) {
            // Found a match! Remove it.
            if (entryList.get(i).contains(target)) {
                entryList.remove(i);
                i--;    // why do we need to decrement i??
            }
        }
    }
}
