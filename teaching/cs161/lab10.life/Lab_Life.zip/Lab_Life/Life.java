/**
 * A class that represents a board for Conway's Life.
 * 
 * @author YOUR NAME 
 * @version TODAY'S DATE
 */

public class Life
{
    private final int DEFAULT_SIZE = 25;    //default height & width of the board
                                            //if bad dimensions are given
    private Cell[][] board;
    
    /**
     * A constructor for a new Life game dimensions must be square!
     * Height and width must be at least 2.
     * If dimensions are not equal or if dimensions are too small,
     * then a N x N board is created, where N is the default size of the board.
     * 
     * @param height the height of the board
     * @param width the width of the board
     */
    public Life(int height, int width) {
        // TODO
    }

    /**
     * Updates the board for the next generation
     */
    public void nextGeneration() {
        // TODO - create temporary board of same dimensions

        // TODO - write a nested loop to traverse all cells in board[][]
    
        // TODO - replace board with the new board!
    }

    /**
     * Returns whether or not a cell is alive.
     * @param row the row index of the cell
     * @param col the col index of the cell
     * @return whether the cell is alive or not
     */
    public boolean isAlive(int row, int col) {
        // TODO - test if row and col are in bounds.
        return false;
    }

    /**
     * Returns the number of living neighbors next to a cell.
     * @param row the row index of the cell
     * @param col the col index of the cell
     * @return the number of living neighbors next to the cell
     */
    public int countLivingNeighbors(int row, int col) {
        int neighbors = 0;
        // TODO - count the number of neighboring elements that are alive!
        return neighbors;
    }

    /**
     * Fills the board with random cells
     */
    public void fillRandom() {
        // TODO
    }

    /**
     * This is for testing -- DO NOT MODIFY
     */
    public void fillSpaceship() {
        // Set every cell to inactive
        for (int i=0; i<board.length; i++) {
            for (int j=0; j<board[i].length; j++) {
                board[i][j] = new Cell(false);
            }
        }

        // spaceship at top left
        board[0][1] = new Cell(true);
        board[1][0] = new Cell(true);
        board[2][0] = new Cell(true);
        board[2][1] = new Cell(true);
        board[2][2] = new Cell(true);
        
        // spaceship in the center
        board[11][12] = new Cell(true);
        board[12][11] = new Cell(true);
        board[13][11] = new Cell(true);
        board[13][12] = new Cell(true);
        board[13][13] = new Cell(true);

        // spaceship bottom right
        board[board.length-3][board.length-2] = new Cell(true);
        board[board.length-2][board.length-1] = new Cell(true);
        board[board.length-1][board.length-3] = new Cell(true);
        board[board.length-1][board.length-2] = new Cell(true);
        board[board.length-1][board.length-1] = new Cell(true);
    }
}
