
/**
 * Just a tester class. DO NOT MODIFY
 *
 * @author David
 * @version 04/03/2025
 */
public class TestNeighbors
{
    /**
     * DO NOT MODIFY
     */
    public static void testCountNeighbors() {
        final int SIZE = 25;
        Life testboard = new Life(SIZE, SIZE);
        testboard.fillSpaceship();
        for (int x = 0; x < SIZE; x++) {
            for (int y = 0; y < SIZE; y++) {
                int neighbors = testboard.countLivingNeighbors(x, y);
                if (neighbors > 0) 
                    System.out.println("Neighbors at [" + x + "][" + y + "]: " + neighbors);
            }
        }
        
    }
}
