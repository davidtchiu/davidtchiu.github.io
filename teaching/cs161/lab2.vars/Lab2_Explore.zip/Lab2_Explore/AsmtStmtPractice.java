/**
 * The methods in this class use the assignment statement to change the values in the
 * fields (instance variables).  They'll be good practice as you get up to speed on
 * how assignment statements work.
 * 
 * @author David Chiu, Brad Richards
 * @version 2020.01.28
 */
public class AsmtStmtPractice {
    private int x;
    private int y;
    private int z;

    /**
     * This constructor calls the reset() method, which gives some initial values to the fields 
     * (instance variables).  You can call reset() again yourself at any time to get back to
     * the starting values.
     */
    public AsmtStmtPractice() {
       this.x = 10;
       this.y = 20;
       this.z = 30;
    }    
    
    /**
     * The reset() method sets x, y, and z back to some initial values.
     */
    public void reset() {
       this.x = 10;
       this.y = 20;
       this.z = 30;
    }
    
    
    /**
     * From here on down are methods you can use to practice your assignment statement
     * comprehension.  For each method, try to predict the values in x, y, and z at the
     * end of the assignment statements.  Then test your predictions by creating an
     * instance of the class, running the method, and using the object inspector to
     * peek at the values in x, y, and z.
     */

    public void test1() {
        this.x = this.z;
        this.z = 100;
    }
    
    public void test2() {
        this.x = this.x;
        this.y = this.y + 2;
        this.z = this.y;
    }
        
    public void test3() {
        // swap the values of this.x and this.z?
        this.x = this.z;
        this.z = this.x;
    }
    
    public void test4() {
        // TODO: You write the code to swap the values of this.x with this.z
        // TODO: You may need to introduce (declare) a third variable...
    }
    
    public void test5() {
        this.y = this.z;
        this.x = this.y;
        this.z = 100;
    }
    
    public void test6() {
        this.z = 100;
        this.x = this.y;
        this.y = this.z;
        this.z = 5;
    }
    
    public void test7() {
        this.x = this.x + 1;
        this.y = this.x * this.y;
    }

    public void test8() {
        this.x = this.x / 5;
        this.y = this.y / 3;
        this.z = this.z / 60;
    }
    
    public void test9() {
        // note: % is the "remainder" operator
        this.x = this.x % 7;
        this.y = this.y % 3;
    }
    
    public void test10() {        
        // note: we can re-use (or, call) other methods too!
        this.test4();   // run test3() method!
        this.test9();   // now run test9() method!
    }
    
    public void test11() {        
        this.x += 3;
        this.x--;
        this.x--;
    }
    
    public void test12() {        
        this.y -= 25;
    }
    
}
