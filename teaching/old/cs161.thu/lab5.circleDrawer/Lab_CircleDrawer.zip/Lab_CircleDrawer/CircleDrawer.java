
/**
 * CircleDrawer instances "remember" a pair of circles, and can make them
 * both visible or invisible.  More precisely, an instance of CircleDrawer
 * contains REFERENCES to two Circle objects.  These references are stored
 * in the instance variables named first and second.
 * 
 * @author Brad Richards
 * @version 9/2009
 */
public class CircleDrawer
{
    private Circle first;       // Reference to my most favorite circle
    private Circle second;      // Reference to my second most favorite circle
    
    /**
     * Default constructor sets both circle references to null.
     */
    public CircleDrawer()
    {
         first = null;
         second = null;
    }
    
    /**
     * Takes two circle instances, uno and dos, and stores them in
     * the fields for later reference.
     * 
     * @param uno a reference to the first Circle to manage
     * @param dos a reference to the second Circle to manage
     */
    public CircleDrawer(Circle uno, Circle dos)
    {
         first = uno;
         second = dos;
    }
    
    /**
     * Makes both of my favorite circles visible
     */
    public void drawCircles()
    {
        first.makeVisible();
        second.makeVisible();
    }
    
    /**
     * Makes both of my favorite circles invisible
     */
    public void eraseCircles()
    {
        first.makeInvisible();
        second.makeInvisible();
    }
    
}

