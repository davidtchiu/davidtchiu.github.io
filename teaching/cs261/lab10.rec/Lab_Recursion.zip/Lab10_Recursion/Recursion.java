import java.util.List;

/**
 * Here are some methods for you to write
 * 
 * @author David 
 * @version 3/24/18
 */
public class Recursion
{
    /**
     * Determine the number of digits in a given integer.
     * For instance, 24002 has 5 digits. We do this through
     * repeated division.
     * 
     * @param n a positive integer
     * @return the number of digits in n
     */
    public static int countDigits(int n) {
        return 0;
    }

    /**
     * Determine the greatest common divisor (gcd) between m and n
     * 
     * @param m a positive integer
     * @param n a positive integer
     * @return the gcd between m and n
     */
    public static int gcd(int m, int n) {
        return 0;
    }

    
    /**
     * Q3: Determines if the given list contains consecutive numbers.
     */
    public static boolean isConsecutive(List<Integer> list) {
        return false;
    }
      
}
