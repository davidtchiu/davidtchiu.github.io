
public class Tester
{
    public static void main(String[] args) {
        CityTracker tracker = new CityTracker();

        tracker.addCity("Seattle", 737015);
        tracker.addCity("Olympia", 55919);
        tracker.addCity("Spokane", 228989);
        tracker.addCity("Tacoma", 219346);
        tracker.addCity("Bellevue", 151854);
        tracker.addCity("Redmond", 76995);
        tracker.addCity("Bellingham", 92489);

        System.out.println(tracker.medianCity());
        // → Bellevue (151854)

        System.out.println(tracker.numCitiesBelow(200000));
        // → 4  (Olympia, Redmond, Bellingham, Bellevue)

        System.out.println(tracker.citiesInRange(80000, 230000));
        // → [Bellingham (92489), Bellevue (151854), Tacoma (219346), Spokane (228989)]

        System.out.println("All cities by population:");
        tracker.listCities();
        // → [Olympia (55919), Redmond (76995), Bellingham (92489), Bellevue (151854),
        //    Tacoma (219346), Spokane (228989), Seattle (737015)]
    }
}
