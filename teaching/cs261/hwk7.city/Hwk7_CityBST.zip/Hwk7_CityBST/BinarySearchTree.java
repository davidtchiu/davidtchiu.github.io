import java.util.List;
import java.util.ArrayList;
/**
 * A binary search tree is an ordered binary tree, in which each node's
 * left subtree contains only items smaller than the data item at that node,
 * and whose right subtree contains only items larger than the data at that 
 * node. Duplicates are ignored.
 * 
 * Note: the generic type E must extend Comparable<E> in order to use
 * compareTo() for comparing keys.
 *
 * @author David
 * @version 8/14/17
 */
public class BinarySearchTree<E extends Comparable<E>> extends BinaryTree<E> implements SearchTree<E> {

    /**
     * Creates an empty binary search tree
     */
    public BinarySearchTree() {
        super();
    }

    /**
     * Creates a binary tree with the given root
     * @param newRoot  reference to the root node
     */
    public BinarySearchTree(Node<E> newRoot) {
        super(newRoot);
    }

    /**
     * Inserts item where it belongs in the tree.
     * Ignores duplicates.
     * @param item  a reference to the data item to add
     */
    @Override
    public void add(E item) {
        this.root = addHelper(root, item);
    }

    /**
     * Helper method to recursively add an item to the BST that is rooted 
     * in the given node (local root).
     * 
     * @param localRoot  the local root node of the subtree in which to 
     *                   attempt to add the item
     * @param item  the item to be added
     * @return new root of the current subtree
     */
    private Node<E> addHelper(Node<E> localRoot, E item) {
        if (localRoot == null) {
            localRoot = new Node<>(item);
        }
        else if (item.compareTo(localRoot.data) < 0) {
            localRoot.left = addHelper(localRoot.left, item);
        }
        else if (item.compareTo(localRoot.data) > 0) {
            localRoot.right = addHelper(localRoot.right, item);
        }
        return localRoot;
    }

    /**
     * A BST is full if every node has either 0 or 2 children.
     */
    public boolean isFull() {
        return isFullHelper(this.root);
    }

    private boolean isFullHelper(Node<E> localRoot) {
        if (localRoot == null) {
            // Base: empty tree is not full
            return false;
        }
        else if (localRoot.left == null && localRoot.right == null) {
            // Base: if there's just a root node, and it's a leaf, tree is full.
            return true;
        }
        else if ((localRoot.left == null && localRoot.right != null) ||
        (localRoot.left != null && localRoot.right == null)) {
            // Base: if there's just a root node, but it's got one child, tree is not full
            return false;
        }
        // recursive case: if there's a root node and there's two children,
        // then test if both subtrees are full
        return isFullHelper(localRoot.left) && isFullHelper(localRoot.right);
    }

    /**
     * Recursively determines whether the tree contains the given item.
     * @param item  an item to search for
     * @return true if found, or false otherwise
     */
    @Override
    public boolean contains(E item) {
        return containsHelper(this.root, item);
    }

    /**
     * Helper method that searches for the item in the current given node.
     * If item is not found in the node, it recursively descends down 
     * either the left or right subtree.
     * 
     * @param item an item to search for
     * @param node the current tree node to search in
     * @return true if found, or false otherwise
     */
    private boolean containsHelper(Node<E> localRoot, E target) {
        if (localRoot == null) {
            //nothing left to search, item must not exist
            return false;
        }
        else if (target.compareTo(localRoot.data) == 0) {
            //found it in the current node!
            return true;
        }
        else if (target.compareTo(localRoot.data) < 0) {
            //try finding it in left subtree
            return containsHelper(localRoot.left, target);
        }
        else {
            //try finding it in right subtree
            return containsHelper(localRoot.right, target);
        }
    }
    
    /**
     * Removes the specified item from the search tree
     * @param target The item to be removed
     * @return a reference to the removed item, or null if not found
     */
    public void remove(E target) {
        this.root = removeHelper(this.root, target);
    }

    private Node<E> removeHelper(Node<E> localRoot, E target) {
        if (localRoot == null) {
            // didn't find the target
            return null;
        }
        else if (target.compareTo(localRoot.data) < 0) {
            // recursively remove target from left subtree
            localRoot.left = removeHelper(localRoot.left, target);
        }
        else if (target.compareTo(localRoot.data)  > 0) {
            // recursively remove target from right subtree
            localRoot.right = removeHelper(localRoot.right, target);
        }
        else {  // target is found at the local root! Now remove it!
            if (localRoot.left == null && localRoot.right == null) {
                // case a: victim is a leaf!
                return null;
            }
            else if (localRoot.left == null) {
                // case b: no left child
                return localRoot.right;
            }
            else if (localRoot.right == null) {
                // case b: left child exists, but right child doesn't
                return localRoot.left;
            }
            else {
                // case c: both children exist
                // replace local root's data its inorder predecessor:
                // that is, the largest item in the left subtree
                localRoot.data = largestHelper(localRoot.left);

                // finally, remove the inorder predecessor node in the left subtree
                localRoot.left = removeHelper(localRoot.left, localRoot.data);
            }
        }
        return localRoot;
    }

    /**
     * Returns the largest data element rooted by the given node. Basically,
     * traverse the right subtree recursively until a leaf is reached.
     * 
     * @param localRoot  local root of the subtree
     * @return the largest data element under the subtree rooted by the given node
     */
    public E largest() {
        return largestHelper(this.root);
    }

    private E largestHelper(Node<E> localRoot) {
        if (localRoot.right == null) {
            // no larger subtree exists
            return localRoot.data;
        }
        return largestHelper(localRoot.right);
    }

    /**
     * @returns the number of leaf nodes in this BST
     */
    public int numLeaves() {
        return numLeavesHelper(this.root);
    }

    public int numLeavesHelper(Node<E> localRoot) {
        if (localRoot == null) {
            // the tree is empty! No leafs here!
            return 0;
        }
        else if (localRoot.left == null && localRoot.right == null) {
            // the root is a leaf! I've got one!
            return 1;
        }
        // the root can't be a leaf, so just add up the number of leaves in
        // both its subtrees
        return numLeavesHelper(localRoot.left) + numLeavesHelper(localRoot.right);
    }

    /**
     * Returns the largest data element rooted by the given node. Basically,
     * traverse the right subtree recursively until a leaf is reached.
     * 
     * @param localRoot  local root of the subtree
     * @return the largest data element under the subtree rooted by the given node
     */
    public E smallest() {
        return smallestHelper(this.root);
    }

    private E smallestHelper(Node<E> localRoot) {
        if (localRoot.left == null) {
            // no smaller subtree exists
            return localRoot.data;
        }
        return smallestHelper(localRoot.left);
    }

    /**
     * The height of the tree is defined as the number of edges along the longest
     * path from root to any leaf.
     * 
     * @returns the height of the current tree
     */
    public int height() {
        return heightHelper(this.root);
    }

    /**
     * Determines the height of the tree from a subtree rooted by the given node
     * @param node  local root of the subtree
     * @return the height of the tree rooted by the given node
     */
    private int heightHelper(Node<E> localRoot) {
        if (localRoot == null) {
            // local root doesn't exist, so height is 0
            return 0;
        }
        else if (localRoot.left == null && localRoot.right == null) {
            // local root is a leafs: height is 0
            return 0;
        }
        else {
            // local root is a non-leaf node: height is the larger height between left and
            // right subtrees plus 1
            return 1 + Math.max(heightHelper(localRoot.left), heightHelper(localRoot.right));
        }
    }

    /**
     * @return the current size of the tree
     */
    public int size() {
        return sizeHelper(this.root);
    }
    private int sizeHelper(Node<E> localRoot) {
        if (localRoot == null) {
            return 0;
        }
        return 1 + sizeHelper(localRoot.left) + sizeHelper(localRoot.right);
    }
    
    
    /**
     * Returns the element at the specified index when the elements of the binary search tree
     * are traversed in sorted (in-order) order. This method assumes that the tree contains no
     * duplicate elements and that subtree sizes can be computed via {@code sizeHelper}.
     *
     * @param index the zero-based index of the element to retrieve (where {@code 0} corresponds
     *              to the smallest element in the tree)
     * @return the element at the specified in-order index
     */
    public E get(int index) {
        // TODO
        return null;
    }
    
    /**
     * @return the count of nodes having data less than the given value.
     */
    public int getRank(E value) {
        // TODO
        return -1;
    }

    /**
     * Returns a list of all elements in the binary search tree that fall within the specified range,
     * inclusive of the endpoints. The elements are returned in sorted (in-order) order.
     *
     * @param begin the lower bound of the range (inclusive)
     * @param end the upper bound of the range (inclusive)
     * @return a list containing all elements {@code e} such that {@code begin <= e <= end},
     *         in ascending order
     */
    public List<E> rangeOf(E begin, E end) {
        // TODO
        return null;
    }
}
