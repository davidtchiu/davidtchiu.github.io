import java.util.List;

/**
 * Tracks cities and their populations using a BinarySearchTree.
 * Supports queries by population rank and range.
 * 
 * @author 
 * @version 
 */
public class CityTracker {
    private BinarySearchTree<City> bst;

    /**
     * Constructs an empty CityTracker.
     */
    public CityTracker() {
        bst = new BinarySearchTree<>();
    }

    /**
     * Adds a new city with the given name and population to the tracker.
     * 
     * @param name the name of the city
     * @param population the population of the city
     */
    public void addCity(String name, int population) {
        // TODO
    }

    /**
     * Returns the city with median population.
     * 
     * @return the median city, or null if no cities are tracked
     */
    public City medianCity() {
        // TODO
        return null;
    }

    /**
     * Returns the number of cities with population strictly less than the given value.
     * 
     * @param population the threshold population
     * @return number of cities with smaller population
     */
    public int numCitiesBelow(int population) {
        // TODO
        return -1;
    }

    /**
     * Returns a list of all cities with populations in the given range [low, high], inclusive.
     * The cities are returned in increasing order of population.
     * 
     * @param low the lower bound of the population range
     * @param high the upper bound of the population range
     * @return list of cities within the specified population range
     */
    public List<City> citiesInRange(int low, int high) {
        // TODO
        return null;
    }

    /**
     * Prints all cities in the tracker, in order of increasing population.
     */
    public void listCities() {
        bst.inOrder();
    }
}