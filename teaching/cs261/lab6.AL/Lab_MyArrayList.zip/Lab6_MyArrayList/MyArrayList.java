import java.util.*;

/**
 * This is my (loose) implementation of ArrayList. In practice you *should* be
 * implementing Java's List interface, but there are too many to write.
 * 
 * @author David
 * @version 10/8/24
 */
public class MyArrayList implements MyList {
    private static final int INITIAL_CAPACITY = 10;    /* initial capacity of MyArrayLists, if not given */
    private int capacity;   /* the current capacity */
    private int size;       /* the current size */
    private double[] data;       /* the underlying array holding the data */

    /**
     * Constructs a new array list
     * @param the initial capacity of the list
     */
    public MyArrayList(int init_cap) {
        // TODO
    }

    /**
     * Constructs a new array list with default capacity
     */
    public MyArrayList() {
        // TODO
    }

    /**
     * @return the element at the given index
     */
    @Override
    public double get(int index) {
        // TODO
        return -1;
    }    

    /**
     * Replaces the element at the given index with a given element
     * @param index position at which to add
     * @param item a new element to add
     * @return the element that was replaced
     */
    @Override
    public double set(int index, double item) {
        // TODO
        return -1;
    }
    
    /**
     * Doubles the capacity of the current list
     */
    private void reallocate() {
        //TODO: instantiate a new array that's double the current capacity

        //TODO: copy over current data elements

        //TODO: update this.capacity to be twice as big

        //TODO: update data to reference new list
    }

    /**
     * Adds the given element to a specified index in the list
     * @param index position at which to add
     * @param item a new element to add
     * @return true
     */
    @Override
    public boolean add(int index, double item) {
        //TODO - caller gave a bad index; throw an exception

        //TODO - need to make room for the new item!

        //TODO - shift all elements from index over to the right by one place

        //TODO - finally, insert the new element and increment this.size
        return true;
    }

    /**
     * Adds the given element to the tail of the list
     * @param item a new element to add
     * @return true
     */
    @Override
    public boolean add(double item) {
        // TODO - call the 2 argument add()
        return true;
    }
    
    /**
     * Searches for the given element
     * @return the index at which the element was found, or -1 if not found
     */    
    @Override
    public int indexOf(double item) {
        // TODO: iterate through all elements of the array (up to position this.size-1)
        // TODO: look for item, and return the index if found
        return -1;  //return -1 if item is not found
    }
    
    /**
     * Removes the element at the given index
     * @param index position at which to add
     * @return the element that was removed
     */
    @Override
    public double remove(int index) {
        // TODO 
        return -1;
    }

    /**
     * Removes the first occurrence of the given item
     * @param item a new element to add
     * @return true if found and replaced, false if not found
     */
    @Override
    public boolean remove(double item) {
       // TODO 
        return false;
    }

    /**
     * @return the number of elements stored in this list.
     */
    @Override
    public int size() {
        return this.size;
    }


    /**
     * @return the string representation of this list
     */
    @Override
    public String toString() {
        String ret = "[";
        for (int i = 0; i < this.size; i++) {
            ret +=  this.data[i];
            //add a comma if not the last element
            if (i < this.size-1) {
                ret += ", ";
            }
        }
        ret += "]";
        return ret;
    }
}