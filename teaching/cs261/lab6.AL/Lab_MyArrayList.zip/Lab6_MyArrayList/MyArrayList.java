/**
 * This is our (loose) implementation of ArrayList
 * 
 * @version 6/17/17
 */
public class MyArrayList implements MyList
{
    private static final int INITIAL_CAPACITY = 10;    /* initial capacity of MyArrayLists, if not given */
    private int capacity;   /* the current capacity */
    private int size;       /* the current size */
    private double[] data;  /* the underlying array holding the data */

    public MyArrayList(int init_cap) {
        this.capacity = init_cap;
        this.data = new double[init_cap]; //initiates the array of Objects
    }

    public MyArrayList() {
        this(INITIAL_CAPACITY);
    }
    
    @Override
    public void clear() {
        this.size = 0;
    }
    
    @Override
    public boolean add(double item) {
        add(this.size, item);
        return true;
    }

    @Override
    public void add(int index, double item) {
        //TODO: caller gave a bad index; throw an exception
        if (index < 0 || index > this.size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        
        //TODO: may need to make room for the new item!
        if (this.size == this.capacity) {
            reallocate();   // this needs to double the internal array and copy everything over
        }
        
        //TODO: shift all elements from index over to the right by one place
        for (int i = this.size; i > index; i--) {
            data[i] = data[i-1];
        }
        
        //TODO: finally, insert the new element
        data[index] = item;
        this.size++;
    }
    
    @Override
    public double get(int index) {
        if (index < 0 || index >= this.size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        return this.data[index];
    }
    
    @Override
    public double set(int index, double new_item) {
        if (index < 0 || index >= this.size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        
        //TODO: save old item before overwriting it
        double tmp = this.data[index];
        
        //TODO: overwrite it
        this.data[index] = new_item;
        return tmp;
    }
    
    @Override
    public double remove(int index) {
        if (index < 0 || index >= this.size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        
        //TODO: save old item before overwriting it
        
        //TODO: need to shift all elements to the left from index to size-1
        //TODO: update the size
        return 0;
    }
    
    @Override
    public boolean remove(double item) {
        try {
            // TODO: get the position of the item (if it exists), then try to remove it 
            return true;
        }
        catch (ArrayIndexOutOfBoundsException e) {
            return false;
        }
    }    
    
    @Override
    public int indexOf(double item) {
        //TODO

        return -1;  //not found
    }    
    
    @Override
    public int size() {
        return this.size;
    }
    
    @Override
    public String toString() {
        String ret = "[";
        for (int i = 0; i < this.size; i++) {
            ret += this.data[i];
            if (i < this.size-1) {
                ret += ", "; //add a comma if not the last element
            }
        }
        ret += "]";
        return ret;
    }
    
    /**
     * Helper method to resize the list by doubling its
     * capacity!
     */
    private void reallocate() {
        //TODO: instantiate a new list that's double the capacity
        
        //TODO: copy current data elements to the new array

        //TODO: update capacity
        
        //TODO: update data to reference new list

    }    
}
