import java.util.Random;
import java.util.Arrays;

public class RuntimeTester extends AbstractRuntimeTester
{
    /**
     * Creates a runtime tester with a list of the given length.
     */    
    public RuntimeTester(int N) {
        super(N);
    }

    /**
     * Runs linear search for the key
     * @return index of first occurrence of key, or -1 if not found
     */
    @Override
    public int linearSearch(int key) {
        this.numStatements = 0;
        // loop through the list from beginning to end
        for (int idx = 0; idx < list.length; idx++) {
            this.numStatements++;
            if (key == list[idx]) {
                return idx; // found the key! return the index and stop!
            }
        }
        // didn't find the key! return -1
        return -1;
    }
    
    /**
     * @return true if a duplicate value was found, and false otherwise
     */
    @Override
    public boolean noDuplicates() {
        // For each value in the list, look for that value in the remaining list
        for (int i = 0; i < list.length; i++) {
            for (int j = i+1; j < list.length; j++) {
                this.numStatements++;
                // Found a match. Return early!
                if (list[i] == list[j]) {
                    return false;
                }
            }
        }
        // No dupes found
        return true;
    }
    
    /**
     * Runs binary search for the key
     * @return index of first occurrence of key, or -1 if not found
     */
    @Override
    public int binarySearch(int key) {
        this.numStatements = 0;
        int startIdx = 0, endIdx = list.length-1;
        while (startIdx <= endIdx) {
            this.numStatements++;
            int midIdx = (startIdx + endIdx)/2; //find mid-point
            if (key == list[midIdx]) {
                return midIdx;    // found the key! return the index and stop!
            }
            else if (key > list[midIdx]) {
                startIdx = midIdx + 1;
            }
            else {
                endIdx = midIdx - 1;
            }
        }
        return -1;     // didn't find the key! return -1
    }

    /**
     * The standard deviation measures the average distance from the mean
     * 
     * @return the standard deviation for the given list
     */
    @Override
    public double stdDev() {
        // TODO
        return 0;
    }  
    
    
    /**
     * Finds the median value in a list (can be unsorted or sorted)
     * This method assumes there are NO duplicates in the list
     * @return the median value of the list
     */
    @Override
    public int median() {
        // TODO
        return -1;
    }
  
}