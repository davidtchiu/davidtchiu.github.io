import java.util.*;

/**
 * This is my (loose) implementation of ArrayList. In practice you *should* be
 * implementing Java's List interface, but there are too many to write.
 * 
 * @author David
 * @version 6/17/17
 */
public class MyArrayList implements MyList {
    private static final int INITIAL_CAPACITY = 10;    /* initial capacity of MyArrayLists, if not given */
    private int capacity;   /* the current capacity */
    private int size;       /* the current size */
    private double[] data;       /* the underlying array holding the data */

    /**
     * Constructs a new array list with default capacity
     */
    public MyArrayList() {
        this(INITIAL_CAPACITY);
    }

    /**
     * Constructs a new array list
     * @param the initial capacity of the list
     */
    public MyArrayList(int init_cap) {
        this.capacity = init_cap;
        this.data = new double[init_cap]; //initiates the array of Objects
    }

    @Override
    public boolean add(double item) {
        return this.add(this.size, item);
    }

    @Override
    public boolean add(int index, double item) {
        //caller gave a bad index; throw an exception
        if (index < 0 || index > this.size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }

        //need to make room for the new item!
        if (this.size == this.capacity) {
            this.reallocate();
        }

        //shift all elements from index over to the right by one place
        for (int i = this.size; i > index; i--) {
            this.data[i] = this.data[i-1];
        }

        //finally, insert the new element
        this.data[index] = item;
        this.size++;
        return true;
    }

    @Override
    public double get(int index) {
        if (index < 0 || index >= size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        return this.data[index];
    }    

    @Override
    public double set(int index, double new_item) {
        if (index < 0 || index >= size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        double old_item = this.get(index);    //save old item before overwriting it
        this.data[index] = new_item; //overwrite it
        return old_item;
    }

    @Override
    public double remove(int index) {
        if (index < 0 || index >= size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }

        //save old item before overwriting it
        double old_item = this.get(index);

        //need to shift all elements to the left from index to size-1
        for (int i = index; i < size-1; i++) {
            this.data[i] = this.data[i+1];
        }
        this.size--;   //update the size of list

        return old_item;
    }

    @Override
    public boolean remove(double item) {
        try {
            // get the position of the item (if it exists), then try to remove it 
            // note: this is *not* a recursive call; it's a call to the other remove()
            this.remove(this.indexOf(item));
            return true;
        }
        catch (ArrayIndexOutOfBoundsException e) {
            // if it made it here, we must've tried to remove from an 
            // invalid index (i.e., -1)
            return false;
        }
    }

    /**
     * Doubles the capacity of the current list
     */
    private void reallocate() {
        //instantiate a new list that's double the capacity
        double[] new_data = new double[this.capacity * 2];

        //copy over current data elements
        for (int i = 0; i < capacity; i++) {
            new_data[i] = this.data[i];
        }

        //update capacity
        this.capacity *= 2;

        //update data to reference new list
        this.data = new_data;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public int indexOf(double item) {
        for (int i = 0; i < size; i++) {
            if (this.data[i] == item) {
                return i;
            }
        }
        return -1;  //not found
    }

    @Override
    public String toString() {
        String ret = "[";
        for (int i = 0; i < size; i++) {
            ret +=  this.data[i];
            //add a comma if not the last element
            if (i < this.size-1) {
                ret += ", ";
            }
        }
        ret += "]";
        return ret;
    }
}