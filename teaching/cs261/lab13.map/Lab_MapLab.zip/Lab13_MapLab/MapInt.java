import java.util.Set;
import java.util.Collection;

/**
 * A very loose Map<K,V> interface. 
 *
 * @author David
 * @version 4/8/18
 */
public interface MapInt<K,V> extends MapPerf {
    /**
     * Associates given value with given key in the map. 
     * @return old value if replaced, or null
     */
    V get(K key);
    
    /**
     * Associates given value with given key in the map. 
     * @return old value if replaced, or null
     * @throws IllegalArgumentException if table is full
     */
    V put(K key, V value);

    /**
     * Removes the entry associated with the given key in the map. 
     * @return old value if replaced, or null
     */
    V remove(K key);

    /**
     * @return true if the key is found
     */
    boolean containsKey(K key);
    
    /**
     * @return a set of keys in the map
     */
    Set<K> keySet();
    
    /**
     * @return a collection of values in the map
     */
    Collection<V> values();
    
    /**
     * @return the number of entries in the map.
     */
    int size();
    
    /**
     * @return String listing the entries in the map.
     */
    String toString();    
}
