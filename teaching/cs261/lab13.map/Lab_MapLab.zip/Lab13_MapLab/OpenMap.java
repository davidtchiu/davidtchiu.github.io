import java.util.*;

/**
 * This is a map with an open addressing implementation.
 * 
 * This code does not (yet) support rehashing
 *   
 * @author David
 * @version 4/8/18
 */

public class OpenMap<K,V> implements MapInt<K,V>
{
    private static final int INITIAL_CAPACITY = 10;
    protected Entry<K,V>[] table;  // Hash table
    protected int size;
    protected long probes;

    /**
     * Constructs a small open-addressing map.
     *
     */
    public OpenMap() {
        this(OpenMap.INITIAL_CAPACITY);    // Creates a hashtable of size 10
    }

    /**
     * Constructs an open-addressing map with a hash table of
     * the given capacity.
     * 
     * @param capacity  positive integer
     * @throws IllegalArgumentException if size is not positive
     */
    public OpenMap(int capacity) {
        if (capacity > 0) {
            this.table = new Entry[capacity];
            this.size = 0;
            resetProbes();
        }
        else {
            throw new IllegalArgumentException("Table size must be positive. Defaulting.");
        }
    }

    @Override
    public V get(K key) {
        int idx = Math.abs(key.hashCode()) % this.table.length;
    
        while (true) {
            this.probes++;  // for counting the number of probes
            if (this.table[idx] == null) {
               return null;
            }
            else if (key.equals(this.table[idx].key)) {
               return this.table[idx].value;
            }
            idx = (idx + 1) % this.table.length;
        }
    }

    @Override
    public V put(K key, V val) {
        int idx = Math.abs(key.hashCode()) % table.length;

        while (true) {
            this.probes++;
            
            // key not found -- add new entry at [idx]
            if (this.table[idx] == null) {
                break;
            }

            // found the key -- this is a replacement of value
            if (key.equals(this.table[idx].key)) {
                V old = this.table[idx].value;
                this.table[idx].value = val;
                return old;
            }
            idx = (idx + 1) % this.table.length;
        }

        // put the new entry here!
        this.table[idx] = new Entry<>(key, val);
        this.size++;
        return null;
    }

    
    @Override
    public V remove(K key) {
        int idx = Math.abs(key.hashCode()) % this.table.length;

        // TODO: like get(), but once you find the key, simply
        // set the entry's key to null.
        
        // TODO: don't forget to count the probes at the beginning
        // of each loop iteration.
        
        // TODO: dont forget to decrement this.size
        
        return null;
    }    

    @Override
    public boolean containsKey(K key) {
        return (this.get(key) != null);
    }

    @Override
    public Set<K> keySet() {
        Set<K> set = new HashSet<>();
        for (Entry<K,V> e : this.table) {
            if (e != null) {
                set.add(e.key);
            }
        }
        return set;
    }

    @Override
    public Collection<V> values() {
        List<V> list = new ArrayList<V>();
        for (Entry<K,V> e : this.table) {
            if (e != null) {
                list.add(e.value);
            }
        }
        return list;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public String toString() {
        String s = "";
        int i, entries_seen = 0;
        for(i = 0; i < this.table.length; i++) {
            if (this.table[i] != null && this.table[i].key != null) {
                s += this.table[i].toString();

                entries_seen++;
                if (entries_seen < this.size) {
                    s += ", ";
                }
            }
        }
        return "[" + s + "]";
    }

    @Override
    public double getLoadFactor() {
        return this.size / (double) this.table.length;
    }
    
    @Override
    public long getProbes() {
        return this.probes;
    }
    
    @Override
    public void resetProbes() {
        this.probes = 0;
    }
    
    /**
     * Our inner Entry class, used to hold (key,value) pairs.
     */
    protected static class Entry<K,V> {
        protected K key;
        protected V value;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public boolean equals(Object other) {
            Entry<K,V> otherEntry = (Entry<K,V>) other;
            return this.key == otherEntry.key || this.key.equals(otherEntry.key);
        }
        
        @Override
        public String toString() {
            return this.key + "=" + this.value;
        }
    }
}
