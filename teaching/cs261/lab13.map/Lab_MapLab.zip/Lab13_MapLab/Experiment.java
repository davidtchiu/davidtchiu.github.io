import java.util.Random;
import java.util.ArrayList;
import java.util.List;


public class Experiment
{    
    private static int MIN_LEN = 5;
    public static Random rand = new Random();
    
    public static void main(String[] args) {
        MapInt<String,String> openMap = new OpenMap<>(100_000);
        Experiment.fillAndTest(openMap, 0.95);
    }
    
    /**
     * Generates random strings of letters, upper and lower case, of the specified length.  
     * You don't need to know how it works.
     * 
     * @return  A random string
     */
    private static String randomString() {
        int length = rand.nextInt(20) + MIN_LEN;
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < length; i++) {
            int offset = rand.nextInt(26);
            sb.append((char)(rand.nextBoolean() ? (offset+'A') : (offset+'a')));
        }
        return sb.toString();
    }

    /**
     * This method takes a map from String to String (that is, both the keys and values are
     * strings) and a desired load factor.  It adds random (key,value) entries to the map 
     * until the specified load factor is reached, then measures and reports how many probes
     * are required on average to do a series of get() calls.
     * 
     * @param map  An instance of one of our map varieties
     * @param load  The load factor at which we want to test
     */
    private static void fillAndTest(MapInt<String,String> map, double load) {
        int NUM_OPS = 100_000;
        List<String> keyList = new ArrayList<>();

        // insert random strings into the map until desired load factor is reached
        while (map.getLoadFactor() < load) {
            String key = randomString();
            keyList.add(key);
            map.put(key, key);
        }

        // testing code...
        map.resetProbes();
        for (int i = 0; i < NUM_OPS; i++) {
            map.get(keyList.get(rand.nextInt(keyList.size()))); // ignore the value
        }
     
        System.out.println("Load factor: " + map.getLoadFactor());
        if (map instanceof OpenMap) {
            System.out.println("Average number of probes (Open Addressing): " + (double) map.getProbes() / NUM_OPS);
            System.out.println("Expected number of probes (Open Addressing): " + (1 + 1.0/(1.0 - map.getLoadFactor()))/2.0 + "\n");
        }
    }
    
}
