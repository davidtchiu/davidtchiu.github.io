
public class Tester
{
    public static void main(String[] args) {
        BinarySearchTree<Integer> my_bst = new BinarySearchTree<>();
        my_bst.add(3);
        my_bst.add(3);  // should ignore
        my_bst.add(4);
        my_bst.add(1);
        my_bst.add(5);
        my_bst.add(2);
        System.out.println(my_bst.toString());
        
        System.out.print("Preorder: ");
        my_bst.preOrder();
        System.out.println();

        System.out.print("Postorder: ");
        my_bst.postOrder();
        System.out.println();

        System.out.print("Inorder: ");
        my_bst.inOrder();
        System.out.println();
    }
}
