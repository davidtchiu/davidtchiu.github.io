/**
 * Instructor-provided code.  You should not modify this file!
 * Represents a musical pitch. R represents a rest, no pitch.
 */

public enum Pitch {
	A, B, C, D, E, F, G, R
}