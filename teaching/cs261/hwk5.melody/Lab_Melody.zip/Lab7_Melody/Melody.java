import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
/**
 * A Melody is a Queue of notes...
 *
 * @author [your names]
 * @version 10/28/2019
 */
public class Melody implements Melodic
{
    private Queue<Note> song;

    /**
     * Constructor for objects of class Melody
     */
    public Melody(Queue<Note> song) {
        this.song = song;
    }

    @Override
    public double getDuration() {
        return Double.NaN;
    }
    
    @Override
    public void play() {
        // TODO -- loop through all notes in the song and play each one!
    }

    @Override
    public void reverse() {
        // TODO -- reverse the notes in the song. Use a Stack!
    }
    
    @Override
    public void changeTempo(double percentage) {
        // TODO -- loop through all notes in the song and adjust their tempo
    }
    
    @Override
    public void append(Melodic other) {
        // TODO -- append the given melody, note by note, to this song
    }
    
    @Override
    public String toString() {
        String str = "";
        for (int numNotes = this.song.size(); numNotes > 0; numNotes--) {
            Note note = this.song.poll();
            str += note.toString() + "\n";
            this.song.offer(note);
        }
        return str;
    }

}