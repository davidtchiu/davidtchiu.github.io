/** 
 * DO NOT MAKE CHANGES TO THIS CLASS
 * 
 * Instructor-provided code.
 * A Note object represents a musical note in scientific music notation. 
 * For example, middle C is represented as C4.
 */

public class Note {
   private Pitch note;
   private double duration;
   private int octave;
   private Accidental accidental;
   private boolean repeat;
   
   /**
    * Constructs a note with the provided duration, pitch, octave, accidental 
    * and repeat settings.
    * @pre duration > 0 and 0 <= octave <= 10
    * @throws IllegalArgumentException
    */
   public Note(double duration, Pitch note, int octave, Accidental accidental, boolean repeat) {
      if(duration <= 0 || octave < 0 || octave > 10) {
         throw new IllegalArgumentException();
      }
      this.note = note;
      this.duration = duration;
      this.octave = octave;
      this.accidental = accidental;
      this.repeat = repeat;
   }
   
   /**
    * Constructs a note with the passed in duration, pitch and repeat settings. 
    * @pre duration > 0
    * @throws IllegalArgumentException
    */
   public Note(double duration, Pitch note, boolean repeat) {
      this(duration, note, 0, Accidental.NATURAL, repeat);
   }
   
   /**
    * @return the length of the note in seconds
    */
   public double getDuration() {
      return this.duration;
   }
   
   /**
    * @return the Accidental value of the note
    */ 
   public Accidental getAccidental() {
      return this.accidental;
   }
   
   /**
    * @return the octave of the note
    */ 
   public int getOctave() {
      return this.octave;
   }
   
   /**
    * @return the pitch of the note (A - G or R of it is a rest)
    */ 
   public Pitch getPitch() {
      return this.note;
   }
   
   /**
    * Sets the duration of the note to be the given time
    * @pre d must be greater than 0
    * @throws IllegalArgumentException
    */ 
   public void setDuration(double d) {
      if(d <= 0) {
         throw new IllegalArgumentException();    
      }
      this.duration = d;
   }
   
   /**
    * Sets the accidental of the note to be the given accidental
    */
   public void setAccidental(Accidental a) {
      this.accidental = a;
   }
   
   /**
    * Sets the octave of the note to be the passed in octave
    * @pre octave must be greater than 0 and less than 10, 
    * @throws IllegalArgumentException
    */
   public void setOctave(int octave) {
      if(octave < 0 || octave > 10) {
         throw new IllegalArgumentException();    
      }
      this.octave = octave;
   }
   
   /**
    * Sets the pitch of the note to be the passed in pitch
    */
   public void setPitch(Pitch pitch) {
      this.note = pitch;
   }
   
   /**
    * Sets the repeat of the note to be the passed in repeat
    */
   public void setRepeat(boolean repeat) {
      this.repeat = repeat;
   }
   
   /**
    * @return true if the note is the beginning or ending 
    * note in a repeated section, false otherwise
    */ 
   public boolean isRepeat() {
      return this.repeat;
   }
   
   /**
    * Plays the sound this note represents
    */ 
   public void play() {
      StdAudio.play(this.duration, this.note, this.octave, this.accidental);
   }
   
   /**
    * @return a string in the format "<duration> <pitch> <repeat>" if the note is a rest,
    *       otherwise returns a string in the format: 
    *       "<duration> <pitch> <octave> <accidental> <repeat>"
    *       For example "2.3 A 4 SHARP true" and "1.5 R true".
    */ 
   public String toString() {
      if(this.note.equals(Pitch.R)) {
         return this.duration + " " + this.note + " " + this.repeat;
      } else {
         return this.duration + " " + this.note + " " + this.octave + " " + this.accidental + " " + this.repeat;
      }
   }
}