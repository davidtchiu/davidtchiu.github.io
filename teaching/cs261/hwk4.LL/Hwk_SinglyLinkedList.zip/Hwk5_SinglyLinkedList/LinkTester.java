import java.util.Random;

public class LinkTester
{
    private static final int NUM_ITEMS = 10_000; /* number of items to insert */

    public static void main(String[] args) {
        SinglyLinkedList<Integer> sl_list = new SinglyLinkedList<>();

        for (int i = 0; i < NUM_ITEMS; i++) {
            sl_list.add(i);
        }

        System.out.println("\nSingly: ");
        System.out.println("Adding " + NUM_ITEMS + " elements: " + " took " + sl_list.getHopCount() + " hops");
        sl_list.resetHopCount();
        System.out.println("Summing up: " + sumUp(sl_list) + " took " + sl_list.getHopCount() + " hops");
        sl_list.resetHopCount();
        System.out.println("Summing down: " + sumDown(sl_list) + " took " + sl_list.getHopCount() + " hops");
        sl_list.resetHopCount();

        // remove all elements from tail
        for (int i = 0; i < NUM_ITEMS; i++) {
            sl_list.remove(sl_list.size()-1);
        }
        System.out.println("Singly removing list: took " + sl_list.getHopCount() + " hops");
    }

    /**
     * A method that takes a linked list of integers and returns 
     * the list's sum. It should work from the front of the list 
     * to the back (low index values to high).
     * @param list 
     * @return the sum of all integers in the list
     */
    private static long sumUp(MyList<Integer> list) {
        long sum = 0;
        for (int i = 0; i < list.size(); i++) {
            sum += list.get(i);
        }
        return sum;
    }

    /**
     * A method that takes a linked list of integers and returns 
     * the list's sum, working from the back of the list to the 
     * front (high index values to low).
     * @param list
     * @return
     */
    private static long sumDown(MyList<Integer> list) {    
        long sum = 0;
        for (int i = list.size()-1; i >= 0; i--) {
            sum += list.get(i);
        }
        return sum;
    }

}
