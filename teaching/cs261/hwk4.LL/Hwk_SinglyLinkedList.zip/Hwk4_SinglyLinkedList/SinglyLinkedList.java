/**
 * This is a loose implementation of the singly linked list.
 * Note: It does not implement Java's List<E> interface.
 *
 * @author David
 * @version 10/15/24
 */
public class SinglyLinkedList<E> implements MyList<E>
{
    private Node<E> head;   /** this is the first node in the list */
    private int size;       /** counts the number of nodes linked in the list */
    private int linkCount;  /** counts the number of hops needed to identify a node */

    /**
     * Creates an empty list
     */
    public SinglyLinkedList() {
        this.head = null;
        this.size = 0;
        this.linkCount = 0;
    }
    
    /**
     * Accessor for the link count.
     * @return  Number of link updates since last reset
     */
    public int getHopCount() {
        return this.linkCount;
    }

    /**
     * Sets the link update counter back to zero.
     */
    public void resetHopCount() {
        this.linkCount = 0;
    }    
    
    /**
     * Removes an item at the given position
     * 
     * @param index the index to the item to remove
     * @return a reference to the item that was removed
     * @throws ArrayIndexOutOfBoundsException if the given index is illegal
     */
    public E remove(int index) {
        // TODO: Is it the 0th item? Call removeFirst
        // TODO: Otherwise, call removeAfter
        return null;
    }
    
    /**
     * Removes an item from the list.
     * 
     * @param item a reference to the item to remove
     * @return true if successful, and false otherwise
     */
    @Override
    public boolean remove(E item) {
        // TODO: Find the item using indexOf, then call the other remove() method
        return true;
    }


    /**
     * Get the data at index
     *
     * @param index The position of the data to return
     * @return The data at index
     * @throws IndexOutOfBoundsException if index is out of range
     */
    @Override
    public E get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("index: " + index);
        }
        //get the node at the specified index, then return its data portion
        Node<E> node = this.getNodeAt(index);
        return node.data;
    }

    /**
     * Store a reference to new_value in the element at position index.
     * @param index The position of the item to change
     * @param new_value The new data
     * @return The data previously at index
     * @throws IndexOutOfBoundsException if index is out of range
     */
    @Override
    public E set(int index, E new_value) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("index: " + index);
        }

        Node<E> node = this.getNodeAt(index);  //get the node at the specified index
        E old_val = node.data;        //save old data value
        node.data = new_value;        //now we can assign new data value
        return old_val;                    //finally, return old value
    }

    /**
     * Adds an element after the specified index
     * @param index The position at which to add this element
     * @param item The new element
     * @return true if successful
     * @throws IndexOutOfBoundsException if index is out of range
     */
    @Override
    public void add(int index, E item) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("index: " + index);
        }

        //Add to head?
        if (index == 0) {
            this.addFirst(item);
        }
        else {
            Node<E> node = this.getNodeAt(index-1);  //get the Node *RIGHT BEFORE* the specified index
            this.addAfter(node, item);               //add the item after that node
        }
    }

    /**
     * Adds an element to the tail of the list
     * @param item The new element
     * @return true if successful
     */
    @Override
    public boolean add(E item) {
        this.add(size, item);
        return true;
    }

    /**
     * Searches the list for the specified item
     * @param item the item to look for
     * @return the index of the first occurrence if found, -1 otherwise
     */
    @Override
    public int indexOf(E item) {
        Node<E> current = this.head; //start iterating from the head node
        for (int i = 0; i < size; i++) {
            if (item.equals(current.data)) {
                return i;
            }
            current = current.next;
            this.linkCount++;
        }
        return -1;  //not found
    }

    /**
     * Add an item to the head of the list.
     * @param item The item to be added
     */
    private void addFirst(E item) {
        //create a new node with the current head as its "next" reference
        Node<E> new_node = new Node<E>(item, this.head);

        //update the new head
        this.head = new_node;

        //update size
        this.size++;
    }

    /**
     * Add a node after a given node
     *
     * @param node The node preceding the new item
     * @param item The item to insert
     */
    private void addAfter(Node<E> node, E item) {
        //create new node with the given node's "next" as its next reference
        Node<E> new_node = new Node<E>(item, node.next);
        node.next = new_node; //link up the new node
        this.size++;
    }

    /**
     * Remove the first node from the list
     * @return The removed node's data or null if the list is empty  
     */
    private E removeFirst() {
        // TODO: get a reference to the current head
        // TODO: if current head exists (not null), set new head
        // TODO: update size if appropriate
        // TODO: Return data at old head or null if list is empty
        return null;
    }

    /**
     * Remove the node after a given node
     *
     * @param node The node before the one to be removed
     * @return The data from the removed node, or null if there is no node to remove
     */
    private E removeAfter(Node<E> node) {
        // TODO: get a reference to the node *after* the given node
        // TODO: if that is not null, link it up to the given node
        // TODO: update size if appropriate
        return null;
    }

    /**
     * Find the node at a specified position
     * @param index The position of the node sought
     * @return The node at index or null if it does not exist
     */
    private Node<E> getNodeAt(int index) {
        //start iterating from the head node
        Node<E> current = this.head;
        for (int i = 0; i < index && current != null; i++) {
            current = current.next;
            this.linkCount++;
        }
        return current;
    }

    /**
     * @return current size of the list
     */
    @Override
    public int size() {
        return this.size;
    }

    /**
     * @return string representation of the list
     */
    @Override
    public String toString() {
        String ret = "[";
        Node<E> current = this.head; //start iterating from the head node
        for (int i = 0; i < size; i++) {
            ret += current.toString();
            if (i < size-1) {
                ret += ", ";
            }
            current = current.next;
        }
        ret += "]";
        return ret;
    }

    /**
     * A list node can store a data element and a reference to the next list node.
     *
     * @author David
     * @version 6/29/17
     */
    private static class Node<E> {
        private E data;
        private Node<E> next;

        /**
         * Creates a new node with a null next field
         *
         * @param new_data a value for the data element
         */
        public Node(E new_data) {
            this.data = new_data;
        }

        /**
         * Creates a new node with a given next field
         *
         * @param init_data a value for the data element
         * @param next_node a reference to the next node in the list
         */
        public Node(E new_data, Node<E> next_node) {
            this.data = new_data;
            this.next = next_node;
        }

        /**
         * @return the string representation of this node
         */
        @Override
        public String toString() {
            return this.data.toString();
        }
    }
}
