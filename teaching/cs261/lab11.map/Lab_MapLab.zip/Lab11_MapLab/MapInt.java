import java.util.Set;

/**
 * A very loose Map<K,V> interface. 
 *
 * @author David
 * @version 4/8/18
 */
public interface MapInt<K,V> extends MapPerf {
    /**
     * Associates given value with given key in the map. 
     * @return old value if replaced, or null
     */
    V get(K key);
    
    /**
     * Associates given value with given key in the map. 
     * @return old value if replaced, or null
     * @throws IllegalArgumentException if table is full
     */
    V put(K key, V value);

    /**
     * @return a set of keys in the map
     */
    Set<K> keySet();
    
    /**
     * @return the number of entries in the map.
     */
    int size();
    
    /**
     * @return String listing the entries in the map.
     */
    String toString();    
}
