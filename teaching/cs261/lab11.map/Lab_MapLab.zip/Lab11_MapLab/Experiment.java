import java.util.Random;
import java.util.ArrayList;


public class Experiment
{    
    private static int MIN_LEN = 5;
    public static Random rand = new Random();
    
    /**
     * Generates random strings of letters, upper and lower case, of the specified length.  
     * You don't need to know how it works.
     * 
     * @return  A random string
     */
    private static String randomString() {
        int length = rand.nextInt(20) + MIN_LEN;
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < length; i++) {
            int offset = rand.nextInt(26);
            sb.append((char)(rand.nextBoolean() ? (offset+'A') : (offset+'a')));
        }
        return sb.toString();
    }

    
    /**
     * This method takes a map from String to String (that is, both the keys and values are
     * strings) and a desired load factor.  It adds random (key,value) entries to the map 
     * until the specified load factor is reached, then measures and reports how many probes
     * are required on average to do a series of get() calls.
     * 
     * @param map  An instance of one of our map varieties
     * @param load  The load factor at which we want to test
     */
    private static void fillAndTest(MapInt<String,String> map, double load) {
        // TODO
    }
    
    
    public static void main(String[] args) {
        // Uncomment me after OpenMap is complete
        // MapInt<String,String> openMap = new OpenMap<>(10000);
        // fillAndTest(openMap, 0.75);
    }
}
