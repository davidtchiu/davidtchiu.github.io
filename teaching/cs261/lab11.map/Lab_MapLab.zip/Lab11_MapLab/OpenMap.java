import java.util.Set;
import java.util.HashSet;

/**
 * This is a map with an open addressing implementation.
 * 
 *   
 * @author David
 * @version 4/8/18
 */

public class OpenMap<K,V> implements MapInt<K,V> {
    protected static final int INITIAL_CAPACITY = 17;
    protected Entry<K,V>[] table;  // Hash table
    protected int size;

    /**
     * Constructs a small open-addressing map.
     *
     */
    public OpenMap() {
        this(INITIAL_CAPACITY);
    }
    
    /**
     * Constructs an open-addressing map with a hash table of
     * the given capacity.
     * 
     * @param capacity  positive integer
     * @throws IllegalArgumentException if size is not positive
     */
    public OpenMap(int capacity) {
        if (capacity > 0) {
            this.table = new Entry[capacity];
            this.size = 0;
        }
        else {
            throw new IllegalArgumentException("Table size must be positive.");
        }
    }
    
    /**
     * @return value associated with the given key, or null if key not found
     */
    @Override
    public V get(K key) {
        // Calculate initial index of the given key
        int idx = Math.abs(key.hashCode()) % table.length;
        
        // Linear probing: As long as we haven't seen all the entries...
        // Keep checking "downward" for a null-spot or an entry that matches the key.
        for (int entries_seen = 0; entries_seen < table.length; entries_seen++) {
            // Nothing in this spot, key not found!
            if (table[idx] == null) {
                return null;
            }
            // Non-null, check if keys are equal!
            else if (key.equals(table[idx].key)) {
                // Returning the entry value
                return table[idx].value;
            }

            // Update the index (and wraparound if necessary)
            idx = (idx + 1) % table.length;
        }
        
        // If we got here, we saw all the entries and didn't find the key!
        return null;
    }
    
    /**
     * Removes an 
     * @return old value if replaced, or null
     */
    @Override
    public V put(K key, V value) {
        // TODO
        return null;
    }

    /**
     * @return a set of keys in the map
     */
    @Override
    public Set<K> keySet() {
        Set<K> set = new HashSet<>();
        for (int i = 0; i < table.length; i++) {
            if (table[i] != null) {
                // ith table entry stores something!
                set.add(table[i].key);
            }
        }
        return set;
    }
    
    /**
     * @return the number of entries in the map.
     */
    @Override
    public int size() {
        // TODO
        return -1;
    }
    
    /**
     * @return String listing the entries in the map.
     */
    @Override
    public String toString() {
        // TODO
        return "";
    }
    
    /**
     * Resets the probe count
     */
    @Override
    public void resetProbes() {
        // TODO
    }
    
    /**
     * @return the number of probes
     */
    @Override
    public long getProbes() {
        // TODO
        return -1;
    }
    
    /**
     * @return the load factor of the map
     */
    @Override
    public double getLoadFactor() {
        // TODO
        return -1;
    }
    
    /**
     * Our inner Entry class, used to hold (key,value) pairs.
     */
    protected static class Entry<K,V> {
        protected K key;
        protected V value;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return key + "=" + value;
        }
    }
}